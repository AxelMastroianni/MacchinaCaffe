package la.macchina.del.caffe;

import java.util.ArrayList;

public class AutomaRiconoscitore {
	
	private ArrayList<String> listaIngressi=new ArrayList<String>();
	private ArrayList<String> listaUscite=new ArrayList<String>();
	
	public AutomaRiconoscitore() {
		
	}
	
	public boolean controllaIngresso(String ingresso) {
		if(listaIngressi.contains(ingresso))
			return true;
		return false;
	}
	
	public boolean controllaUscita(String uscita) {
		if(listaUscite.contains(uscita))
			return true;
		return false;
	}
	
	public void aggiungiIngresso(String ingresso) {
		listaIngressi.add(ingresso);
	}
	
	public void aggiungiUscita(String uscita) {
		listaUscite.add(uscita);
	}

}
