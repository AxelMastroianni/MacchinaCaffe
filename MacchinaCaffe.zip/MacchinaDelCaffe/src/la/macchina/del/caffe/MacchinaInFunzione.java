package la.macchina.del.caffe;

import java.io.IOException;
import java.util.*;

public class MacchinaInFunzione {

	public static void main(String[] args) throws Exception, IOException {
		// TODO Auto-generated method stub
		String nomeBevanda="";
		int importo=0;
		Scanner tastiera=new Scanner(System.in);
		String risposta="";
		LeggiFile lettore=new LeggiFile();
		lettore.letturaFile("./src/Bevande.txt");
		ArrayList<String> nomiBevande=lettore.getListaBevande();
		ArrayList<Integer> prezziBevande=lettore.getListaPrezzi();
		MacchinaCaffe macchinetta=new MacchinaCaffe();
		macchinetta.leggiBevande(nomiBevande, prezziBevande);
		macchinetta.aggiungiBevande();
		MenuBevande menu=new MenuBevande(macchinetta.getListaBevande());
		macchinetta.generaStati();
		macchinetta.creaDSA();
		while(!risposta.equals("fine")) {
			nomeBevanda=menu.selezionaBevanda();
			Bevanda selezionata=macchinetta.selezionaBevanda(nomeBevanda);
			int prezzoOriginale=selezionata.getPrezzo();
			System.out.println("Puoi inserire: ");
			macchinetta.mostraMonete();
			while(macchinetta.collegamenti(selezionata, prezzoOriginale, importo)==null) {
				System.out.println("Inserisci una moneta: "); importo=tastiera.nextInt();
			}
			System.out.println("Hai avuto: "+selezionata.getNome());
			System.out.println("Il tuo resto �: "+macchinetta.getResto());
			importo=0;
			System.out.println("Premi un tasto per continuare. Io aspetto il prossimo cliente");
			risposta=tastiera.next();
		}

	}

}
