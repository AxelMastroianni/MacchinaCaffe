package la.macchina.del.caffe;

public class Bevanda {
	
	private int prezzo=0;
	private String nome="";
	
	public Bevanda(String nome, int prezzo) {
		this.nome=nome;
		this.prezzo=prezzo;
	}

	public int getPrezzo() {
		return prezzo;
	}

	public void setPrezzo(int prezzo) {
		this.prezzo = prezzo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	

}
