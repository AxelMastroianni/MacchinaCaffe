package la.macchina.del.caffe;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class LeggiFile {
	
	private ArrayList<String> listaBevande=new ArrayList<String>();
	public ArrayList<String> getListaBevande() {
		return listaBevande;
	}

	public void setListaBevande(ArrayList<String> listaBevande) {
		this.listaBevande = listaBevande;
	}

	public ArrayList<Integer> getListaPrezzi() {
		return listaPrezzi;
	}

	public void setListaPrezzi(ArrayList<Integer> listaPrezzi) {
		this.listaPrezzi = listaPrezzi;
	}

	private ArrayList<Integer> listaPrezzi=new ArrayList<Integer>();
	
	public LeggiFile() {
		
	}
	
	public void letturaFile(String nomeFile) throws IOException {
		FileReader file=new FileReader(nomeFile);
		BufferedReader lettore=new BufferedReader(file);
		String rigaLetta=lettore.readLine();
		while(rigaLetta!=null) {
			leggiBevanda(rigaLetta);
			leggiPrezzo(rigaLetta);
			rigaLetta=lettore.readLine();
		}
		file.close();
	}
	
	private void leggiPrezzo(String rigaLetta) {
		rigaLetta=rigaLetta.toUpperCase();
		rigaLetta=rigaLetta.trim();
		String prezzo="";
		for(int i=0;i<rigaLetta.length();i++) {
			if(rigaLetta.charAt(i)>='0' && rigaLetta.charAt(i)<='9')
				prezzo+=rigaLetta.charAt(i);
		}
		listaPrezzi.add(Integer.parseInt(prezzo));
	}

	private void leggiBevanda(String rigaLetta) {
		rigaLetta=rigaLetta.toUpperCase();
		rigaLetta=rigaLetta.replaceAll(" ", "");
		String bevanda="";
		int i=0;
		while(rigaLetta.charAt(i)>='A' && rigaLetta.charAt(i)<='Z') {
			bevanda+=rigaLetta.charAt(i);
			i++;
		}
		listaBevande.add(bevanda);
	}
	

}
