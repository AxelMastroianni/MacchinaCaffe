package la.macchina.del.caffe;

import java.util.*;

import javax.naming.InsufficientResourcesException;

public class MacchinaCaffe {
	
	private AutomaRiconoscitore riconoscitore=new AutomaRiconoscitore();
	private ArrayList<Bevanda> listaBevande=new ArrayList<Bevanda>();
	public static String[] listaMonete= {"0","1","2","5","10","20","50","100","200"};
	private Map<Integer,LinkedList<String>> diagrammaStati = new HashMap<Integer,LinkedList<String>>();
	private ArrayList<String> stati=new ArrayList<String>();
	private int resto=0;
	private Scanner tastiera=new Scanner(System.in);
	
	public int getResto() {
		return resto;
	}

	public void setResto(int resto) {
		this.resto = resto;
	}

	public MacchinaCaffe() {
		for(int i=0;i<listaMonete.length;i++)
			riconoscitore.aggiungiIngresso(listaMonete[i]);
	}
	
	public void leggiBevande(ArrayList<String> nomi, ArrayList<Integer> prezzi) {
		while(!nomi.isEmpty() || !prezzi.isEmpty()) {
			String nome=nomi.remove(0);
			int prezzo=prezzi.remove(0);
			listaBevande.add(new Bevanda(nome,prezzo));
		}
	}
	
	public ArrayList<Bevanda> getListaBevande() {
		return listaBevande;
	}

	public void setListaBevande(ArrayList<Bevanda> listaBevande) {
		this.listaBevande = listaBevande;
	}

	private int prezzoMassimo() {
		int max=0;
		for(int i=0;i<listaBevande.size();i++) {
			int prezzo=listaBevande.get(i).getPrezzo();
			if(prezzo>max)
				max=prezzo;
		}
		return max;
	}
	
	public void creaDSA() {
		int dimensione=prezzoMassimo();
		for(int i=0;i<dimensione;i++) {
			diagrammaStati.put(i, new LinkedList<String>());
		}
	}
	
	public void generaStati() {
		int dimensione=prezzoMassimo();
		for(int i=0;i<=dimensione;i++) {
			stati.add("meno "+i);
		}
	}
	
	public Bevanda selezionaBevanda(String nomeBevanda) {
		nomeBevanda=nomeBevanda.toUpperCase();
		nomeBevanda=nomeBevanda.replaceAll(" ", "");
		try {
			if(riconoscitore.controllaUscita(nomeBevanda)) {
				for(int i=0;i<listaBevande.size();i++) {
					Bevanda bevanda=listaBevande.get(i);
					if(nomeBevanda.equals(bevanda.getNome()))
						return bevanda;
				}
			}
			throw new IllegalArgumentException();
		}catch(IllegalArgumentException | InputMismatchException e) {
			System.out.println("Bevanda inesistente, prego, reinserire: ");
			nomeBevanda=tastiera.next();
			return selezionaBevanda(nomeBevanda);
		}
	}
	
	public Bevanda collegamenti(Bevanda selezionata,int prezzoPartenza, int importo) throws Exception {
		try {
			if(riconoscitore.controllaIngresso(importo+"")) {
				int rimanente=selezionata.getPrezzo()-importo;
				if(rimanente<=0) {
					setResto(Math.abs(rimanente));
					selezionata.setPrezzo(prezzoPartenza);
					return selezionata;
				}
				selezionata.setPrezzo(rimanente);
				System.out.println(stati.get(rimanente));
				return null;
			}
			throw new IllegalArgumentException();
		}catch(IllegalArgumentException | InputMismatchException e) {
			System.out.println("L'importo inserito non � valido, prego, reinserire se non vuoi perdere i soldi: ");
			importo=tastiera.nextInt();
			return collegamenti(selezionata,prezzoPartenza,importo);
		}
	}
	
	public void mostraMonete() {
		for(int i=0;i<listaMonete.length;i++)
			System.out.print(listaMonete[i]+"\t");
		System.out.println();
	}
	
	public void aggiungiBevande() {
		for(int i=0;i<listaBevande.size();i++)
			riconoscitore.aggiungiUscita(listaBevande.get(i).getNome());
	}

}
