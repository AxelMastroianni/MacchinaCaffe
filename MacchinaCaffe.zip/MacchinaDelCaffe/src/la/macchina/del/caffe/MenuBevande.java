package la.macchina.del.caffe;

import java.util.ArrayList;
import java.util.Scanner;

public class MenuBevande {
	
	private ArrayList<Bevanda> listaBevande;
	private Scanner tastiera=new Scanner(System.in);
	
	public MenuBevande(ArrayList<Bevanda> listaBevande) {
		this.listaBevande=listaBevande;
	}
	
	public String selezionaBevanda() {
		System.out.println("Scrivi il nome della bevanda che gradisci: ");
		System.out.println("-----------------------");
		for(int i=0;i<listaBevande.size();i++)
			System.out.println(i+". " + listaBevande.get(i).getNome());
		System.out.println("------------------------");
		String nomeBevanda=tastiera.next();
		return nomeBevanda;
	}

}
